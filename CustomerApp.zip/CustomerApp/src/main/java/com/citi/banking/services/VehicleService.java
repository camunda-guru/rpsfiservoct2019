package com.citi.banking.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.citi.banking.models.Vehicle;
import com.citi.banking.repositories.VehicleRepository;


@Service
public class VehicleService {
    @Autowired
	private VehicleRepository repo;
    
    private boolean status;
    //insert query
    @CacheEvict(value = "vehicles", allEntries=true)
    public Vehicle saveVehicle(Vehicle vehicle)
    {
    	return repo.save(vehicle);
    }
    
    //select all
    @Cacheable(value="vehicles")
    public List<Vehicle> getAllVehicles()
    {
    	return repo.findAll();
    }
    
    //select by engine no
    
    public Vehicle getVehicleById(long engineNo)
    {
    	return repo.findById(engineNo).orElse(null);
    }
    
    //delete query
    
    public boolean deleteVehicleById(long engineNo)
    {
    	repo.deleteById(engineNo);
    	status=true;
    	return status;
    	
    }
    
    
    
    
}
