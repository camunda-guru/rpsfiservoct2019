package com.citi.banking.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.citi.banking.models.Visa;

import com.citi.banking.services.VisaService;

@RestController
public class VisaController {
	@Autowired
	private VisaService visaService;
	
	@CrossOrigin(origins = "*")
	@PostMapping("/addvisa")
	public @ResponseBody Visa add(@RequestBody Visa visa)
	{
		
		return visaService.addVisa(visa);
	}
	
	@CrossOrigin(origins = "*")
	@GetMapping("/getvisa")

	public List<Visa> getAll()
	{
		return visaService.getAllVisa();
	}
	//getvisa byid
		@CrossOrigin("*")
		@GetMapping("/getvisabyid/{id}")
		public @ResponseBody Visa getVisaDataById(@PathVariable  long id )
		{
			
			return this.visaService.getVisaById(id);
		}
		
		//delete customer
		//getvisa byid
		@CrossOrigin("*")
		@GetMapping("/deletevisabyid/{id}")
		public void deleteCustomerDataById(@PathVariable  long id )
			{
				
				this.visaService.deleteVisaById(id);
			}

	
	// Update Customer
		@CrossOrigin("*")
		@PutMapping("/updatevisa/{id}")
	
		public Visa updateCustomer(@PathVariable(value = "id") long id,
		                                         @RequestBody Visa visa) {

		   Visa visaObj = this.visaService.getVisaById(id);		            
		   visaObj=visa;
           visaObj.setApplicationNo(id); 
		    Visa updatedVisa = this.visaService.addVisa(visaObj);
		    return updatedVisa;
		}
}
