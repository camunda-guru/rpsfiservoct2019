package com.citi.banking.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Visa")
public class Visa {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ApplicationNo")
	private long applicationNo;
	@Column(name="FirstName",length=50,nullable=false)
	private String firstName;
	@Column(name="LastName",length=50,nullable=false)
	private String lastName;
	@Column(name="Address1",length=150,nullable=false)
	private String address1;
	@Column(name="Address2",length=150,nullable=false)
	private String address2;
	@Column(name="City",length=50,nullable=false)
	private String city;
	@Column(name="State",length=50,nullable=false)
	private String state;
	@Column(name="PostalCode")
	private long zip;
	@Column(name="Country",length=50,nullable=false)
	private String country;
	@Column(name="email",length=100,nullable=false)
	private String email;
	@Column(name="password",length=12,nullable=false)
	private String password;
	@Column(name="Place",length=50,nullable=false)
	private String place;
	@Column(name="Days")
	private int days;
	private String purpose;
	public long getApplicationNo() {
		return applicationNo;
	}
	public void setApplicationNo(long applicationNo) {
		this.applicationNo = applicationNo;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getAddress2() {
		return address2;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public long getZip() {
		return zip;
	}
	public void setZip(long zip) {
		this.zip = zip;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getPlace() {
		return place;
	}
	public void setPlace(String place) {
		this.place = place;
	}
	public int getDays() {
		return days;
	}
	public void setDays(int days) {
		this.days = days;
	}
	public String getPurpose() {
		return purpose;
	}
	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}
	

}
