package com.citi.banking.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.citi.banking.models.Policy;


public interface PolicyRepository extends JpaRepository<Policy,Long>{

}
