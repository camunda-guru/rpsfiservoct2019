package com.citi.banking.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="PolicyHolder")
public class PolicyHolder {
    @Id
    @Column(name="AdharCardNo")
	private long adharCardNo;
    @Column(name="FirstName",nullable=false,length=50)
	private String firstName;
    @Column(name="LastName",nullable=false,length=50)
	private String lastName;
    @Column(name="Email",nullable=false,length=50)
	private String email;
    @Column(name="MobileNo")
	private long mobileNo;
    
    //@OneToOne(mappedBy="owner",fetch=FetchType.LAZY)
    //private Policy policy;
    
         
    
    
	/*public Policy getPolicy() {
		return policy;
	}
	public void setPolicy(Policy policy) {
		this.policy = policy;
	}*/
	public long getAdharCardNo() {
		return adharCardNo;
	}
	public void setAdharCardNo(long adharCardNo) {
		this.adharCardNo = adharCardNo;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	} 
    
}
