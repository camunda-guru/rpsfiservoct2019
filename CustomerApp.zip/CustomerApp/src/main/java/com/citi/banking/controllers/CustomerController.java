package com.citi.banking.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.citi.banking.models.Customer;
import com.citi.banking.services.CustomerService;

@RestController
public class CustomerController {
    @Autowired
	private CustomerService customerService;
	@PostMapping("/addcustomer")
	@CrossOrigin(origins = "*")
	
	public @ResponseBody Customer add(@RequestBody Customer customer)
	{
		
		return customerService.addCustomer(customer);
	}
	
	@GetMapping("/getcustomers")
	@CrossOrigin(origins = "*")
	public List<Customer> getAll()
	{
		return customerService.getAllCustomers();
	}
	//getcustomer byid
		@CrossOrigin("*")
		@GetMapping("/getcustomerbyid/{id}")
		public @ResponseBody Customer getCustomerDataById(@PathVariable  int id )
		{
			
			return this.customerService.getCustomerById(id);
		}
		
		//delete customer
		//getcustomer byid
		@CrossOrigin("*")
		@GetMapping("/deletecustomerbyid/{id}")
		public void deleteCustomerDataById(@PathVariable  int id )
			{
				
				this.customerService.deleteCustomerById(id);
			}

	
	// Update Customer
		@CrossOrigin("*")
		@PutMapping("/updatecustomer/{id}")
	
		public Customer updateCustomer(@PathVariable(value = "id") int id,
		                                         @RequestBody Customer customer) {

		    Customer cust = this.customerService.getCustomerById(id);
		            
	        cust.setCustomerId(id);
		    cust.setName(customer.getName());
		    cust.setEmailId(customer.getEmailId());
		    cust.setMobileNo(customer.getMobileNo());
		    cust.setDob(customer.getDob());
		    cust.setAddress(customer.getAddress());

		    Customer updatedCustomer = this.customerService.addCustomer(cust);
		    return updatedCustomer;
		}

}
