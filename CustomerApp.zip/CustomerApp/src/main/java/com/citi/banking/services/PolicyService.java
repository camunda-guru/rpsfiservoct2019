package com.citi.banking.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citi.banking.models.Policy;
import com.citi.banking.models.PolicyHolder;
import com.citi.banking.models.Vehicle;
import com.citi.banking.repositories.PolicyRepository;

@Service
public class PolicyService {
	@Autowired
	private PolicyRepository repo;
    @Autowired
	private PolicyHolderService phService;
    @Autowired
	private VehicleService vehicleService;
    private boolean status;
    //insert query
    
    public Policy savePolicy(Policy policy, long engineNo, long adharCardNo)
    {
    	Vehicle vehicle=vehicleService.getVehicleById(engineNo);
    	PolicyHolder policyHolder=phService.getPolicyHolderById(adharCardNo); 
    	policy.setVehicle(vehicle);
        policy.setOwner(policyHolder);      	
    	return repo.save(policy);
    }
    
    //select all
    
    public List<Policy> getAllPolicies()
    {
    	return repo.findAll();
    }
    
    //select by policy no
    
    public Policy getPolicyById(long policyNo)
    {
    	return repo.findById(policyNo).orElse(null);
    }
    
    //delete query
    
    public boolean deletePolicyById(long policyNo)
    {
    	repo.deleteById(policyNo);
    	status=true;
    	return status;
    	
    }
}
