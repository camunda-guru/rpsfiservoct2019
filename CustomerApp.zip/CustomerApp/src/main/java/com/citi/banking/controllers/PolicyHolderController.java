package com.citi.banking.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.citi.banking.models.PolicyHolder;
import com.citi.banking.services.PolicyHolderService;


@RestController
public class PolicyHolderController {

	@Autowired
	private PolicyHolderService policyHolderService;
	
	@CrossOrigin("*")
	@PostMapping("/addPolicyHolder")
	public @ResponseBody PolicyHolder addPolicyHolder(@RequestBody PolicyHolder policyHolder)
	{
		return policyHolderService.savePolicyHolder(policyHolder);
	}
	@CrossOrigin("*")
	@GetMapping("/getallPolicyHolders")
	public List<PolicyHolder> getAllPolicyHolders()
	{
		return policyHolderService.getAllPolicyHolders();
	}
	@CrossOrigin("*")
	@GetMapping("/getPolicyHolderbyid/{adharCardNo}")
	public PolicyHolder getPolicyHolderById(@PathVariable("adharCardNo") long adharCardNo)
	{
		return policyHolderService.getPolicyHolderById(adharCardNo);
	}
	
}
