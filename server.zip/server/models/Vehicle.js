const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// Define collection and schema for Post
let Vehicle = new Schema({
  engineNo: {
    type: Number
  },
  regNo: {
    type: String
  },
  regDate:{
    type: String
  },
  model:{
        type:String
      },
  color:{
    type:String
  }
},{
    collection: 'vehicles'
});

module.exports = mongoose.model('Vehicle', Vehicle);
