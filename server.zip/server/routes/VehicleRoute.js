const express = require('express');

var cors=require("cors");
const app = express();
app.use(cors());
const VehicleRoute = express.Router();

// Require Post model in our routes module
let Vehicle = require('../models/Vehicle');

// Defined store route
VehicleRoute.route('/add').post(function (req, res) {
    // Website you wish to allow to connect
    res.setHeader('Access-Control-Allow-Origin', '*');

    // Request methods you wish to allow
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');

    // Request headers you wish to allow
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');

    // Set to true if you need the website to include cookies in the requests sent
    // to the API (e.g. in case you use sessions)
    res.setHeader('Access-Control-Allow-Credentials', true);
  let vehicle = new Vehicle(req.body);
  vehicle.save()
    .then(post => {
    res.status(200).json(vehicle);
    })
    .catch(err => {
    res.status(400).send("unable to save to database");
    });
});

// Defined get data(index or listing) route
VehicleRoute.route('/').get(function (req, res) {
    // Website you wish to allow to connect
    res.setHeader('Access-Control-Allow-Origin', '*');

    // Request methods you wish to allow
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');

    // Request headers you wish to allow
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');

    // Set to true if you need the website to include cookies in the requests sent
    // to the API (e.g. in case you use sessions)
    res.setHeader('Access-Control-Allow-Credentials', true);
    Vehicle.find(function (err, vehicles){
    if(err){
      console.log(err);
    }
    else {
      res.json(vehicles);
    }
  });
});

// Defined delete | remove | destroy route
VehicleRoute.route('/delete/:id').get(function (req, res) {
    // Website you wish to allow to connect
    res.setHeader('Access-Control-Allow-Origin', '*');

    // Request methods you wish to allow
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');

    // Request headers you wish to allow
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');

    // Set to true if you need the website to include cookies in the requests sent
    // to the API (e.g. in case you use sessions)
    res.setHeader('Access-Control-Allow-Credentials', true);
    console.log(req.params.id);
    Vehicle.deleteOne({regNo: req.params.id}, function(err, vehicle){
        if(err) res.json(err);
        else res.json(req.params.id);
    });
});

module.exports = VehicleRoute;
