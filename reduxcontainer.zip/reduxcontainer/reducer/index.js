import { combineReducers } from 'redux';
import vehicles from './vehicleReducer';

export default combineReducers({
    vehicles: vehicles
});
